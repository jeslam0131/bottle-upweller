
Important: files in this directory are temporary and are only tracked while
the project is opened (so that the scripts can be edited while the project is opened).

i.e.: on save the current copy is persisted within the project file and will
be erased when there are more than 5 scripts temporary directories created.
